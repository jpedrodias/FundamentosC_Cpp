#include <stdio.h>
#include <locale.h>

/*
Escreve um programa de mostre os primeiro 20 números naturais.
*/
int main(){
    for(int i = 1; i <= 20; i++){
        printf("%d\n", i);
    }
    return 0;
}