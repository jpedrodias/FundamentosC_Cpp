/*
Exercício 1
Cria uma função maior() que recebe dois números e devolve o maior.
*/
#include <stdio.h>

int qual_o_maior(int valor_a, int valor_b) {
    if (valor_a > valor_b) {
        return valor_a;
    } else {
        return valor_b;
    }
}


int main() {
    int numero_1, numero_2;

    printf("Digite o valor de a: ");
    scanf("%d", &numero_1);

    printf("Digite o valor de b: ");
    scanf("%d", &numero_2);

    int maior = qual_o_maior(numero_1, numero_2);

    printf("O maior número é: %d\n", maior);

    return 0;
}